package shop;

@SuppressWarnings("serial")
public class MusicShopException  extends Exception{

	public MusicShopException(String s) {
		super(s);
	}
}
