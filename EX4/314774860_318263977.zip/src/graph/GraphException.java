package graph;

@SuppressWarnings("serial")
public class GraphException extends Exception{
	public GraphException(String s) {
		super(s);
	}
}
