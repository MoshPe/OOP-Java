package images;

public class TwoColorImage extends BaseImage {

	private RGB zero, one;
	private TwoDFunc func;

	public TwoColorImage(int width, int height, RGB zero, RGB one, TwoDFunc func) { // constructor
		super(width, height);
		this.zero = zero;
		this.one = one;
		this.func = func;
	}

	@Override
	public RGB get(int x, int y) {
		double normX, normY, temp;
		// normalize x and y
		normX = x <= 0 ? 0 : (double) x / getWidth();
		normY = y <= 0 ? 0 : (double) y / getHeight();
		// get the output from the function with them
		temp = func.f(normX, normY);
		// make sure we in the range of 0-1
		temp = temp <= 0 ? 0 : temp >= 1 ? 1 : temp;
		return RGB.mix(one, zero, temp); // make RGB color with "temp" ratio
	}
	public static void main(String []argc) {
		Image i = new TwoColorImage(200, 100, RGB.BLACK, 
				RGB.RED, new Func1());
				Displayer.display(i);

	}
}
