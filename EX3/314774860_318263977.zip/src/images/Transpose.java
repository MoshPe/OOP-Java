package images;

public class Transpose extends ImageDecorator {

	public Transpose(Image base) { // constructor
		super(base.getHeight(), base.getWidth(), base); // switch between height and width
	}

	@Override
	public RGB get(int x, int y) { // get method
		// if y greater then the width, set width, else, set y,,,,,,same with x and
		// height
		return getBase().get(y > getWidth() ? getWidth() : y, x > getHeight() ? getHeight() : x);
	}
}
