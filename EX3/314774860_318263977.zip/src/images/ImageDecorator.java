package images;

public abstract class ImageDecorator implements Image {
	private int width;
	private int height;
	private Image base;

	public ImageDecorator(int width, int height, Image base) {
		this.height = height;
		this.width = width;
		this.base = base;
	}
	
	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	protected Image getBase() {
		return base;
	}

	public abstract RGB get(int x, int y);
}
