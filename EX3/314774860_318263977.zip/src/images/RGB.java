package images;

//this class represent color 
public class RGB {

	private double red;
	private double green;
	private double blue;

	// some static colors
	public static final RGB BLACK = new RGB(0);
	public static final RGB WHITE = new RGB(1);
	public static final RGB RED = new RGB(1, 0, 0);
	public static final RGB GREEN = new RGB(0, 1, 0);
	public static final RGB BLUE = new RGB(0, 0, 1);

	public RGB(double red, double green, double blue) { // constructor
		this.red = red;
		this.green = green;
		this.blue = blue;
	}

	public RGB(double grey) { // make it grey
		red = grey;
		green = grey;
		blue = grey;
	}

	public double getRed() {
		return red;
	}

	public double getBlue() {
		return blue;
	}

	public double getGreen() {
		return green;
	}

	public RGB invert() {
		return new RGB(1 - red, 1 - green, 1 - blue);
	}

	public RGB filter(RGB filter) { // make new RGB color with the values of the current * filter
		return new RGB(red * filter.red, green * filter.green, blue * filter.blue);
	}

	public static RGB superpose(RGB rgb1, RGB rgb2) { // add 2 colors together and make new RGB color out of them
		double red, green, blue;
		red = rgb1.red + rgb2.red;
		green = rgb1.green + rgb2.green;
		blue = rgb1.blue + rgb2.blue;
		if (red > 1) // checking if we didn't reach value > 1
			red = 1;
		if (green > 1)
			green = 1;
		if (blue > 1)
			blue = 1;
		return new RGB(red, green, blue);
	}

	public static RGB mix(RGB rgb1, RGB rgb2, double alpha) { // mix 2 colors with "alpha" ratio between them
		return new RGB(alpha * rgb1.red + (1 - alpha) * rgb2.red, alpha * rgb1.green + (1 - alpha) * rgb2.green,
				alpha * rgb1.blue + (1 - alpha) * rgb2.blue);
	}

	@Override
	public String toString() {
		return String.format("<%.4f, %.4f, %.4f>", red, green, blue);
	}
}
