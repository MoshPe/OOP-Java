package images;

public class Mix extends BinaryImageDecorator {
	private double alpha;

	public Mix(Image base1, Image base2, double alpha) { // constructor
		super(base1, base2);
		this.alpha = alpha;
	}

	@Override
	protected RGB combineBaseImages(int x, int y) { // specific function for Mix, used in superclass
		return RGB.mix(getBase1().get(x, y), getBase2().get(x, y), alpha);
	}
}
