package images;

public interface TwoDFunc {
	public double f(double x, double y);
}
