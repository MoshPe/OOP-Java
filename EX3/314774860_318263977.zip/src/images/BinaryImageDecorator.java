package images;

public abstract class BinaryImageDecorator implements Image {
	private int width, height;
	private Image base1, base2;

	public BinaryImageDecorator(Image base1, Image base2) { // constructor
		this.base1 = base1;
		this.base2 = base2;
		this.width = Math.max(base1.getWidth(), base2.getWidth());
		this.height = Math.max(base1.getHeight(), base2.getHeight());
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public RGB get(int x, int y) { // get function for all the subclasses
		if (isDefined(base1, x, y)) {
			if (isDefined(base2, x, y))
				return combineBaseImages(x, y); // specific method for each subclass
			return base1.get(x, y);
		} else if (isDefined(base2, x, y))
			return base2.get(x, y);
		return RGB.BLACK;
	}

	protected boolean isDefined(Image base, int x, int y) { // check if the given x and y are defined in image
		if (base.getWidth() >= x)
			if (base.getHeight() >= y)
				return true;
		return false;
	}

	protected abstract RGB combineBaseImages(int x, int y);

	protected Image getBase1() {
		return base1;
	}

	protected Image getBase2() {
		return base2;
	}
}
