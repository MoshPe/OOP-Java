package images;

public class Superpose extends BinaryImageDecorator {

	public Superpose(Image base1, Image base2) { // constructor
		super(base1, base2);
	}

	@Override
	protected RGB combineBaseImages(int x, int y) { // specific function for superpose, used in superclass
		return RGB.superpose(getBase1().get(x, y), getBase2().get(x, y));
	}
}
