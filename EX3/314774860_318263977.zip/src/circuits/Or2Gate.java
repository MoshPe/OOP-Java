package circuits;
//this class represent Or gate with 2 gates
public class Or2Gate extends OrGate {

	public Or2Gate(Gate p1, Gate p2) {
		super(new Gate[] { p1, p2 });	//make Or gate with 2 gates
		// TODO Auto-generated constructor stub
	}
}
