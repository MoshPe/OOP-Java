package circuits;

//This class represent a gate with the name and value from the user
public class VarGate extends Gate {

	private String name;
	private boolean value;
	private boolean isTheValueSet = false;

	public VarGate(String name) { // constructor, save name and set inside gates to null
		super(null);
		this.name = name;
	}

	@Override
	protected boolean func(boolean[] inValues) throws CircuitException {
		if (isTheValueSet) // if the value is set, return it
			return value;
		else // else, throw exception
			throw new CircuitException("Var value is not set");
	}

	// set value method
	public void setVal(boolean value) {
		isTheValueSet = true; // mark as the value is set
		this.value = value; // set value
	}

	@Override
	public String getName() {
		return "V" + name;
	}

	@Override
	public Gate simplify() {
		if (isTheValueSet) {
			if (value == true) // if the value is true, return TrueGate
				return TrueGate.instance();
			else // else, return FalseGate
				return FalseGate.instance();
		}
		return this; // if the value isn't set - return the current gate
	}
}
