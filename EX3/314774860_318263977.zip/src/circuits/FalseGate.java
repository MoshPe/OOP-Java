package circuits;

//this class represent true gate(singleton), same as TrueGate
public class FalseGate extends Gate {

	private static FalseGate singleton = null;

	private FalseGate(Gate[] inGate) {
		super(inGate);
	}

	public static Gate instance() {
		if (singleton == null)
			singleton = new FalseGate(null);
		return singleton;
	}

	@Override
	protected boolean func(boolean[] inValues) {
		return false;
	}

	@Override
	public String getName() {
		return "F";
	}

	@Override
	public Gate simplify() {
		return singleton;
	}
}
