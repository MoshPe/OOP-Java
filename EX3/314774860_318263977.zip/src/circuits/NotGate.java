package circuits;

//this class represent Not gate
public class NotGate extends Gate {

	public NotGate(Gate inGate) {
		super(new Gate[] { inGate });
		// TODO Auto-generated constructor stub
	}

	@Override
	protected boolean func(boolean[] inValues) {
		return inValues[0] == false; // return true if the value is false, else, false
	}

	@Override
	public String getName() {
		return "NOT";
	}

	@Override
	public Gate simplify() { // this methods simplify the gates in the current gate
		if (inGates[0].simplify() instanceof TrueGate) // if the gate inside is TrueGate, return FalseGate
			return FalseGate.instance();
		if (inGates[0].simplify() instanceof FalseGate) // same but the upside
			return TrueGate.instance();
		if (inGates[0] instanceof NotGate) // else, if the gate is NotGate, return the gate inside him
			return inGates[0].inGates[0].simplify();
		return this;
	}

}
