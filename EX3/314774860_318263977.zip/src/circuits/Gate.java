package circuits;

//this abstract class represent general logic gate 
public abstract class Gate {

	protected Gate[] inGates;

	public Gate(Gate[] inGate) {	//set the gates in the current gate
		this.inGates = inGate;
	}
	//calculate the value of the current gate
	public boolean calc() throws CircuitException {
		boolean[] inValues;
		if (inGates == null)	//if we dont have any gates inside = true or false gates
			return func(null);	//call func and return its value
		inValues = new boolean[inGates.length];	//set array of values for each gate inside the current gate
		int i = 0;
		for (Gate help : inGates) {
			inValues[i++] = help.calc();	//set in array the values for each gate (recursion)
		}
		return func(inValues);	//call func with the array and return its value
	}

	protected abstract boolean func(boolean[] inValues) throws CircuitException;

	public abstract String getName();

	public abstract Gate simplify();
	
	// return String representation of the gate
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append(getName());
		if (inGates == null)
			return str.toString();
		str.append('[');
		for (Gate temp : inGates) {
			str.append(temp.toString());
			str.append(", ");
		}
		str.delete(str.length() - 2, str.length());
		str.append(']');
		return str.toString();
	}
}
