package circuits;

//this class represent true gate(singleton)
public class TrueGate extends Gate {
	private static TrueGate singleton = null;

	// private constructor to limit the instance of the class
	private TrueGate(Gate[] inGate) {
		super(inGate);
	}

	// this method do: return the instance of the class, if we have it, or make one
	// and return it
	public static Gate instance() {
		if (singleton == null) // if we don't have instance the class
			singleton = new TrueGate(null); // make one and save it - null because we don't have gates inside true gate
		return singleton; // if we have instance of the class or we made one, return it
	}

	@Override
	protected boolean func(boolean[] inValues) { // return the value of the gate
		return true;
	}

	@Override
	public String getName() {
		return "T";
	}

	@Override
	public Gate simplify() {
		return this;
	}

}
